import Room from "../models/Room.js";

export const addRoom = async (req, res) => {
    const room = await Room.create(req.body);
    res.json(room);
};

export const getRooms = async (req, res) => {
    const rooms = await Room.find();
    res.json(rooms);
};