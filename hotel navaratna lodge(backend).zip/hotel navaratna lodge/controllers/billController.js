import Bill from "../models/Bill.js";

export const createBill = async (req, res) => {
    const { roomCharges, foodCharges, serviceCharges } = req.body;

    const total = roomCharges + foodCharges + serviceCharges;

    const bill = await Bill.create({
        ...req.body,
        total
    });

    res.json(bill);
};

export const getBills = async (req, res) => {
    const bills = await Bill.find();
    res.json(bills);
};