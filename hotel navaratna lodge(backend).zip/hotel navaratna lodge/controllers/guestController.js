import Guest from "../models/Guest.js";

export const addGuest = async (req, res) => {
    const guest = await Guest.create(req.body);
    res.json(guest);
};

export const getGuests = async (req, res) => {
    const guests = await Guest.find();
    res.json(guests);
};