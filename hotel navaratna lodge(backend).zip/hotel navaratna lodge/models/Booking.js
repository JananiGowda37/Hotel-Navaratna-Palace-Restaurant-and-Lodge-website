import mongoose from "mongoose";

const bookingSchema = new mongoose.Schema({
    guestName: String,
    mobile: String,
    checkIn: Date,
    checkOut: Date,
    guests: Number,
    roomType: String
});

export default mongoose.model("Booking", bookingSchema);