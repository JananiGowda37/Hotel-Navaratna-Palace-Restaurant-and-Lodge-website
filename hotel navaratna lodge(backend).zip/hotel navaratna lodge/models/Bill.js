import mongoose from "mongoose";

const billSchema = new mongoose.Schema({
    guestName: String,
    roomCharges: Number,
    foodCharges: Number,
    serviceCharges: Number,
    total: Number
});

export default mongoose.model("Bill", billSchema);