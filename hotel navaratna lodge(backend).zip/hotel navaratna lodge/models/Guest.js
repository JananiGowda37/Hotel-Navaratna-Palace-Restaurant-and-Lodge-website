import mongoose from "mongoose";

const guestSchema = new mongoose.Schema({
    name: String,
    mobile: String,
    address: String,
    idProof: String,
    nationality: String,
    email: String
});

export default mongoose.model("Guest", guestSchema);