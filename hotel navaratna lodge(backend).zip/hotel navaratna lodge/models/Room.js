import mongoose from "mongoose";

const roomSchema = new mongoose.Schema({
    roomNumber: Number,
    type: String,
    floor: Number,
    price: Number,
    capacity: Number,
    amenities: [String],
    status: {
        type: String,
        enum: ["Available", "Occupied", "Reserved", "Cleaning", "Maintenance"],
        default: "Available"
    }
});

export default mongoose.model("Room", roomSchema);