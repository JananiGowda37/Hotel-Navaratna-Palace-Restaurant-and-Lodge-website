import mongoose from "mongoose";

const orderSchema = new mongoose.Schema({
    items: [
        {
            menuItem: { type: mongoose.Schema.Types.ObjectId, ref: "Menu" },
            quantity: Number
        }
    ],
    orderType: {
        type: String,
        enum: ["DineIn", "Takeaway", "Delivery"]
    },
    status: {
        type: String,
        enum: ["Pending", "Cooking", "Ready", "Served"],
        default: "Pending"
    }
}, { timestamps: true });

export default mongoose.model("Order", orderSchema);