import Order from "../models/Order.js";

export const getDailySales = async (req, res) => {
    const orders = await Order.find();
    res.json({
        totalOrders: orders.length
    });
};