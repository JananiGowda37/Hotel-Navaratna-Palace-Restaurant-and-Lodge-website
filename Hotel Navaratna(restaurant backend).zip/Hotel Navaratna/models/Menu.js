import mongoose from "mongoose";

const menuSchema = new mongoose.Schema({
    name: String,
    category: String,
    price: Number,
    description: String,
    availability: {
        type: Boolean,
        default: true
    }
});

export default mongoose.model("Menu", menuSchema);