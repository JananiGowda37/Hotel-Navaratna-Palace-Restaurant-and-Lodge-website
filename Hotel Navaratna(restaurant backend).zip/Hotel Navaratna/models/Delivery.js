import mongoose from "mongoose";

const deliverySchema = new mongoose.Schema({
    orderId: String,
    deliveryBoy: String,
    status: String
});

export default mongoose.model("Delivery", deliverySchema);