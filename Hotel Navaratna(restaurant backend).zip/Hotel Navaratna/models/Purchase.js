import mongoose from "mongoose";

const purchaseSchema = new mongoose.Schema({
    supplier: String,
    item: String,
    quantity: Number
});

export default mongoose.model("Purchase", purchaseSchema);