import mongoose from "mongoose";

const reservationSchema = new mongoose.Schema({
    customerName: String,
    phone: String,
    date: String,
    time: String,
    people: Number
});

export default mongoose.model("Reservation", reservationSchema);