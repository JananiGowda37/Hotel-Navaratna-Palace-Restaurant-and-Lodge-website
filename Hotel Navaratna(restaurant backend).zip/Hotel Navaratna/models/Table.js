import mongoose from "mongoose";

const tableSchema = new mongoose.Schema({
    tableNumber: Number,
    capacity: Number,
    section: String,
    status: {
        type: String,
        enum: ["Available", "Occupied", "Reserved", "Cleaning"],
        default: "Available"
    }
});

export default mongoose.model("Table", tableSchema);