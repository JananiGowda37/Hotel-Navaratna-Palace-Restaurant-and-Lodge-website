import mongoose from "mongoose";

const billSchema = new mongoose.Schema({
    orderId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Order"
    },
    totalAmount: Number,
    tax: Number,
    discount: Number,
    finalAmount: Number,
    paymentMode: {
        type: String,
        enum: ["Cash", "Card", "UPI"]
    }
}, { timestamps: true });

export default mongoose.model("Bill", billSchema);