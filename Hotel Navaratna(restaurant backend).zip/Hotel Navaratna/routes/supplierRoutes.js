import express from "express";
import { addSupplier, getSuppliers } from "../controllers/supplierController.js";

const router = express.Router();

router.post("/", addSupplier);
router.get("/", getSuppliers);

export default router;