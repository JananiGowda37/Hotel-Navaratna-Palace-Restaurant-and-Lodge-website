import express from "express";
import { createUser, loginUser, getUsers, deleteUser } from "../controllers/userController.js";

const router = express.Router();

router.post("/register", createUser);
router.post("/login", loginUser);
router.get("/", getUsers);
router.delete("/:id", deleteUser);

export default router;