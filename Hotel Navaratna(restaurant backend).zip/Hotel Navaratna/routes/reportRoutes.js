import express from "express";
import { getDailySales } from "../controllers/reportController.js";

const router = express.Router();

router.get("/daily", getDailySales);

export default router;