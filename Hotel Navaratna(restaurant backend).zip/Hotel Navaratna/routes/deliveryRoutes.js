import express from "express";
import { assignDelivery, getDeliveries } from "../controllers/deliveryController.js";

const router = express.Router();

router.post("/", assignDelivery);
router.get("/", getDeliveries);

export default router;