import express from "express";
import { createTable, getTables } from "../controllers/tableController.js";

const router = express.Router();

router.post("/", createTable);  
router.get("/", getTables);

export default router;