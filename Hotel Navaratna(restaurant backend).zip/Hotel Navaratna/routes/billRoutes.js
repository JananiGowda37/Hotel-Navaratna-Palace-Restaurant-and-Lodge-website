import express from "express";
import { generateBill } from "../controllers/billController.js";

const router = express.Router();

router.post("/", generateBill);

export default router;