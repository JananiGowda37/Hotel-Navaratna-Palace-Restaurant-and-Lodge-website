import Delivery from "../models/Delivery.js";

export const assignDelivery = async (req, res) => {
    const delivery = await Delivery.create(req.body);
    res.json(delivery);
};

export const getDeliveries = async (req, res) => {
    const deliveries = await Delivery.find();
    res.json(deliveries);
};