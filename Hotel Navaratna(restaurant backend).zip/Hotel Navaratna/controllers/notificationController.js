export const sendNotification = (req, res) => {
    res.json({
        message: "Notification sent successfully"
    });
};