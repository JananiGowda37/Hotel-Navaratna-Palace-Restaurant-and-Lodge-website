import Inventory from "../models/Inventory.js";

export const addItem = async (req, res) => {
    const item = await Inventory.create(req.body);
    res.json(item);
};

export const getItems = async (req, res) => {
    const items = await Inventory.find();
    res.json(items);
};