import Bill from "../models/Bill.js";
import Order from "../models/Order.js";
import mongoose from "mongoose";

export const generateBill = async (req, res) => {
    try {
        const { orderId, tax, discount, paymentMode } = req.body;

        if (!mongoose.Types.ObjectId.isValid(orderId)) {
            return res.status(400).json({ msg: "Invalid Order ID" });
        }

        const order = await Order.findById(orderId).populate("items.menuItem");

        if (!order) {
            return res.status(404).json({ msg: "Order not found" });
        }

        let total = 0;

        order.items.forEach(item => {
            total += item.menuItem.price * item.quantity;
        });

        const taxAmount = (total * tax) / 100;
        const discountAmount = (total * discount) / 100;

        const finalAmount = total + taxAmount - discountAmount;

        const bill = await Bill.create({
            orderId,
            totalAmount: total,
            tax,
            discount,
            finalAmount,
            paymentMode
        });

        res.json(bill);

    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};