import Table from "../models/Table.js";

export const createTable = async (req, res) => {
    const table = await Table.create(req.body);
    res.json(table);
};

export const getTables = async (req, res) => {
    const tables = await Table.find();
    res.json(tables);
};