import Order from "../models/Order.js";

//  create order
export const createOrder = async (req, res) => {
    try {
        const order = await Order.create(req.body);

        res.status(201).json({
            message: "Order created successfully",
            order
        });

    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// get all orders
export const getOrders = async (req, res) => {
    try {
        const orders = await Order.find().populate("items.menuItem");

        res.json(orders);

    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

//  update order status
export const updateOrderStatus = async (req, res) => {
    try {
        const order = await Order.findByIdAndUpdate(
            req.params.id,
            { status: req.body.status },
            { new: true }
        );

        res.json({
            message: "Order status updated",
            order
        });

    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};