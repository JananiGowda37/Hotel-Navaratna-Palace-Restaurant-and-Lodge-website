export const getDashboard = (req, res) => {
    res.json({
        sales: 5000,
        activeTables: 10,
        pendingOrders: 5
    });
};