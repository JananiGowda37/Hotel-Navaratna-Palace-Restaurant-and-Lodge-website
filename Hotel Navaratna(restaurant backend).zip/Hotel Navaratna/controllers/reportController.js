import Order from "../models/Order.js";

export const getDailySales = async (req, res) => {
    try {
        const orders = await Order.find();

        let totalRevenue = 0;

        orders.forEach(order => {
            order.items.forEach(item => {
                totalRevenue += item.quantity * 100; // simple logic
            });
        });

        res.json({
            totalOrders: orders.length,
            totalRevenue
        });

    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};