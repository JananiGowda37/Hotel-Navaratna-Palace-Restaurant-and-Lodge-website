export const generateInvoice = (req, res) => {
    res.json({
        message: "Invoice generated successfully",
        data: req.body
    });
};