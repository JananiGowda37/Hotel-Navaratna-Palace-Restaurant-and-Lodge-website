import Menu from "../models/Menu.js";

export const addMenu = async (req, res) => {
    const item = await Menu.create(req.body);
    res.json(item);
};

export const getMenu = async (req, res) => {
    const menu = await Menu.find();
    res.json(menu);
};