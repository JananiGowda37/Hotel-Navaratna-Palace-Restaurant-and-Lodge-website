import Reservation from "../models/Reservation.js";

export const createReservation = async (req, res) => {
    const reservation = await Reservation.create(req.body);
    res.json(reservation);
};

export const getReservations = async (req, res) => {
    const reservations = await Reservation.find();
    res.json(reservations);
};