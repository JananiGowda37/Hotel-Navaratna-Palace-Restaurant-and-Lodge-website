import Customer from "../models/Customer.js";

export const addCustomer = async (req, res) => {
    const customer = await Customer.create(req.body);
    res.json(customer);
};

export const getCustomers = async (req, res) => {
    const customers = await Customer.find();
    res.json(customers);
};