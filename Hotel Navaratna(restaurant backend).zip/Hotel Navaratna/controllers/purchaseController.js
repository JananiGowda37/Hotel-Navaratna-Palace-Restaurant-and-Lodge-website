import Purchase from "../models/Purchase.js";

export const createPurchase = async (req, res) => {
    const purchase = await Purchase.create(req.body);
    res.json(purchase);
};

export const getPurchases = async (req, res) => {
    const purchases = await Purchase.find();
    res.json(purchases);
};